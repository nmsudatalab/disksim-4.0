/*
 * Author: Yonggang Liu
 * This abstract class serves as the interface for the strategies on the PFSClient module.
 */

#include "PFSClientStrategy.h"

PFSClientStrategy::~PFSClientStrategy() {

}
